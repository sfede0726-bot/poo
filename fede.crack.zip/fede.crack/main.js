// ==========================================
// 1. clase básica y métodos simples
// ==========================================

class celularsimple {
    constructor(marca, modelo) {
        this.marca = marca;
        this.modelo = modelo;
        this.bateria = 100;
    }

    cargar() {
        this.bateria = 100;
        console.log(`el ${this.marca} ${this.modelo} está cargado al 100%.`);
    }

    usar(minutos) {
        this.bateria -= minutos;
        if (this.bateria < 0) {
            this.bateria = 0;
        }
        console.log(`batería restante del ${this.marca}: ${this.bateria}%`);
    }
}

// probando 
const celular1 = new celularsimple("samsung", "a54");
const celular2 = new celularsimple("iphone", "6s");

celular1.usar(30);
celular1.cargar();

celular2.usar(50);
celular2.cargar();

//Validar “usar(minutos)”. Si los minutos no son un número mayor a 0, mostrar un
//error con “console.error” y no modificar la batería.

if (usar(minutos)<0){

    console.error

}

// ==========================================
// 2. encapsulamiento
// ==========================================

class celularseguro {
    #pin;
    #intentos;
    #bloqueado;

    constructor(marca, modelo, pin) {
        this.marca = marca;
        this.modelo = modelo;
        this.#pin = pin;
        this.#intentos = 0;
        this.#bloqueado = false;
    }

    desbloquear(piningresado) {
        // Verificar si el celular ya está bloqueado
        if (this.#bloqueado) {
            console.log("Error: El celular está bloqueado por seguridad.");
            return false;
        }

        // Validar el PIN ingresado
        if (this.#pin === piningresado) {
            this.#intentos = 0; // Reiniciar intentos en caso de éxito
            return true;
        } else {
            this.#intentos++; // Sumar 1 intento fallido
            
            // Comprobar si alcanzó o superó los 3 fallos
            if (this.#intentos >= 3) {
                this.#bloqueado = true;
                console.log("¡Alerta! Demasiados intentos fallidos. El celular ha sido bloqueado.");
            } else {
                console.log(`PIN incorrecto. Intentos fallidos: ${this.#intentos}/3`);
            }
            
            return false;
        }
    }

    cambiarpin(pinactual, pinnuevo) {
        if (this.#bloqueado) {
            console.log("Error: No se puede cambiar el PIN, el celular está bloqueado.");
            return;
        }

        if (this.#pin === pinactual) {
            this.#pin = pinnuevo;
            this.#intentos = 0; // Opcional: reiniciar intentos al cambiar el PIN con éxito
            console.log("PIN cambiado correctamente.");
        } else {
            this.#intentos++;
            if (this.#intentos >= 3) {
                this.#bloqueado = true;
                console.log("¡Alerta! PIN actual incorrecto. Demasiados fallos, el celular ha sido bloqueado.");
            } else {
                console.log(`Error: El PIN actual es incorrecto. Intentos fallidos: ${this.#intentos}/3`);
            }
        }
    }
}

//6. Agregar las propiedades privadas “#intentos” y “#bloqueado”. Cada PIN
// incorrecto suma 1 intento. Con 3 fallos el celular queda bloqueado. Un
// desbloqueo exitoso reinicia los intentos.


const celularprivado = new celularseguro("samsung", "a54", "1234");

console.log(celularprivado.desbloquear("0000"));  
console.log(celularprivado.desbloquear("1111")); 
console.log(celularprivado.desbloquear("2222")); 

console.log(celularprivado.desbloquear("1234")); 



// ==========================================
// 3. herencia (extends y super)
// ==========================================

class celularbaseherencia {
    constructor(marca, modelo, pin) {
        this.marca = marca;
        this.modelo = modelo;
        this.pin = pin;
        this.bateria = 50;
        this.bloqueado = true;
    }

    cargar() {
        console.log(`el celular ${this.marca} está cargando...`);
    }

    usar() {
        console.log(`estás usando el celular ${this.marca} ${this.modelo}.`);
    }

    desbloquear(piningresado) {
        if (piningresado === this.pin) {
            this.bloqueado = false;
            console.log("celular desbloqueado con éxito.");
        } else {
            console.log("pin incorrecto.");
        }
    }
}

class smartphone extends celularbaseherencia {
    constructor(marca, modelo, pin, sistema) {
        super(marca, modelo, pin); // hereda las propiedades del padre
        this.sistema = sistema;
        this.apps = []; 
    }

    instalarapp(nombre) {
        this.apps.push(nombre);
        console.log(`la aplicación "${nombre}" se ha instalado en ${this.sistema}.`);
    }
}

// probando 
const mismartphone = new smartphone("motorola", "g60", "4321", "android");
mismartphone.cargar();
mismartphone.desbloquear("4321");
mismartphone.instalarapp("whatsapp");

//6. Agregar el método “desinstalarApp(nombre)”. Buscar la posición con “findIndex”;
// si la app no está, notificar al usuario; si está, eliminarla con splice.

//7. Agregar el método “listarApps()”. Mostrar las apps numeradas con un forEach. Si
//no hay ninguna, mostrar “No hay apps instaladas.”



class GestorApps {
    constructor() {
        this.apps = []; // Supongamos que aquí se almacenan las apps
    }

    // 6.desinstalar u
    desinstalarApp(nombre) {
        const index = this.apps.findIndex(app => app === nombre); // O app.nombre === nombre si son objetos

        if (index === -1) {
            console.log(`La aplicación "${nombre}" no está instalada.`);
        } else {
            // Eliminamos la app encontrada con splice
            this.apps.splice(index, 1);
            console.log(`La aplicación "${nombre}" ha sido desinstalada.`);
        }
    }

    // 7.  listar aplicaciones instaladas
    listarApps() {
        if (this.apps.length === 0) {
            console.log("No hay apps instaladas.");
        } else {
            console.log("Apps instaladas:");
            this.apps.forEach((app, index) => {
                console.log(`${index + 1}. ${app}`);
            });
        }
    }
}
//


// ==========================================
// 4. polimorfismo
// ==========================================

class celularpolimorfismo {
    encender() {
        console.log("el celular se enciende.");
    }

    // Método base para simular el uso en minutos
    usar(minutos) {
        console.log(`Usando el dispositivo por ${minutos} minutos.`);
    }
}

class smartphonepoly extends celularpolimorfismo {
    constructor(sistema) {
        super();
        this.sistema = sistema;
    }

    encender() {
        console.log(`iniciando ${this.sistema}...`);
    }

    // 6. En Smartphone, reescribir el método “usar(minutos)” para que gaste el doble,
    // reutilizando el método del padre con super.usar(minutos * 2).
    usar(minutos) {
        super.usar(minutos * 2);
    }
}

class celularbasico extends celularpolimorfismo {
    encender() {
        console.log("el celular básico enciende con su musiquita clásica y vibración.");
    }
}

// a
const dispositivos = [
    new celularpolimorfismo(),
    new smartphonepoly("xiaomi"),
    new celularbasico()
];

dispositivos.forEach(dispositivo => {
    dispositivo.encender();
});

// PRUEBA
const miSmartphone = new smartphonepoly("Android");
miSmartphone.usar(10); // Mostrará: "Usando el dispositivo por 20 minutos."

/* 
porque el foreach solo da la orden general encender(), pero al momento 
de ejecutarla, js revisa de qué clase es cada objeto en particular y 
aplica el método que le corresponde a esa clase.
*/
                                                                                    //        ↑↑↑
//6. En Smartphone, reescribir el método “usar(minutos)” para que gaste el doble,  //          |
//reutilizando el método del padre con super.usar(minutos * 2).                   //           |
//|                                                                                            |
//|                                                                                            |
//|                                                                                            |
//|--------------------------------------------------------------------------------------------|

