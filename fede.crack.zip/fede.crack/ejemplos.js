
//clases -> son plantillas genericas representativas de algo tangible o intangible
//sintaxis -> class nombreclase (singular, primera letra mayuscula){}
 class Animal {
    //constructor -> inicializar o invocar las propiedades de la clase
    constructor(cant_patas, tipo_pelaje, altura, sonido) {//parametros -> reciben un valor
        //this -> clave = valor
        this.cant_patas = cant_patas;
        this.tipo_pelaje = tipo_pelaje,
            this.altura = altura;
        this.sonido = sonido;
    }
    //metodo estatico
    emitirsonido() {
        return `El ${this.nombre} hace el siguiente sonido: ${this.sonido}`
    };
    //lectura
    get pelajeMayusculas() {
        return this.tipo_pelaje.toUpperCase();
    };
    //permite modificar
    set cambiarPatas(cant_patas) {
        if (cant_patas < 0) {
            console.log("Envie una cantidad de patas real")
        } else {
            this.cant_patas = cant_patas;
        }
    }

}





//instancia de animal
//nombre variable = new (nueva instancia) + clase (animal) + (valores)
let conejo = new Animal(4, "Pelo corto", "Peuqeño");
let perro = new Animal(4, "Pelo largo", "Grande");
let arana = new Animal(8, "Pelo corto", "peuqeño")

//acceso a propiedades -> natociones de punto
console.log("el perro tiene " + perro.tipo_pelaje);

//acceso a propiedades -> corchetes
console.log("la araña tiene " + arana["cant_patas"] + " patas");

console.log("el conejo tiene " + conejo["cant_patas"] + " patas");

conejo.cant_patas = 10;
console.log("el conejo tiene " + conejo.cant_patas + " patas")


//agregar pripiedades a una instancia
perro.nombre = "Perro";//-> A se vez, le damos un valor
perro.sonido = "Guau";

console.log(perro.emitirsonido());

console.log(arana.pelajeMayusculas)


class Producto {
    constructor(nombreP, precioP, stockP, conservaP) {
        this.nombre = nombreP;
        this.precio = precioP;
        this.stock = stockP;
        this.conserva = conservaP;
    }
    mostrarNombre() {
        return `el nombre del producto es ${this.nombre}`
    }
    resumen() {
        return `El nombre es ${this.nombre} y el precio es ${this.precio}`
    }

    get mostrarNombreMay() {
        return this.nombre.toUpperCase()
    }

    set stockDispoible(stock) {
        if (stock > 0) {
            console.log("hay disponibilidad del producto")
        } else {
            console.log("producto no disponible")
        }
    }

    set verificarNombre(nombrenuevo) {
        if (nombrenuevo === "" || nombrenuevo.length < 3) {
            console.log("No podes cambiarlo")
        } else {
            this.nombre = nombrenuevo.trim();
            console.log("el nombre es: " + this.nombre)
        }
    }

    set disponible(stock) {
        if (stock > 0) {
            console.log(`el producto esta disponible: true`)
        } else {
            console.log(`el producto no esta disponible: false`)
        }
    }


}


let fideos = new Producto("Don Felipe", 2500, 110, "Aire libre")
let manzana = new Producto("Tres Ases", 300, 240, "Aire Libre")
let carne = new Producto("Vacio", 18000, 100, "Heladera o Freezer")
//1)
console.log("los fideos salen: " + fideos.precio)

console.log("La marca de las manzanas es: " + manzana["nombre"])

console.log("El vacio esta: " + carne["precio"])

// 2)
console.log(fideos.mostrarNombre())
console.log(manzana.mostrarNombre())
console.log(carne.mostrarNombre())

console.log(carne.mostrarNombreMay)

// 3)
manzana.stockDispoible = 0;


manzana.stockDispoible = 200;

// 4)
delete carne.conserva;
console.log(carne.conserva)//Me devuelve undefined al eliminarlo
 
/*
1) crear 3 instancias de producto y agregarle una propiedad destinta a cada una

2) llamar metodo "mostrarNombre" para las 3, y llamar el getter para la ultima

3) probar en la segunda instancia el setter, enviando stock = 0 y luego un stock mayor a 0

4)eliminar la pripiedad "conservaP" de la primer instancia (resolvemos en tele)
*/
/*
console.log(fideos.resumen())
console.log(manzana.resumen())
console.log(carne.resumen())

fideos.verificarNombre = "";

console.log(stock.disponible()) 
*/
//abtraccion
class CuentaBancaria {
    constructor(titular, saldoInicial) {
        this.titular = titular;
        this.saldo = saldoInicial;
    }

    depositar(monto) {
        if (monto <= 0) {
            console.error("el monto debe ser mayor a 0.");
            return;
        } else {
            this.saldo += monto
            console.log("deposito exitoso. Saldo actual: $" + this.saldo);
        }
    }

    retirar(monto) {
        if (monto > this.saldo) {
            console.error("fondos insuficientes");
        } else {
            this.saldo -= monto;
            console.log("Retiro exitoso. Saldo actual: $" + this.saldo);
        }
    }
}

let cuenta1 = new CuentaBancaria("juan", 1000)
cuenta1.depositar(300)
cuenta1.depositar(-1000)

cuenta1.retirar(2000)
cuenta1.retirar(500)


//Encapsulamiento

class Usuario {
    #password
constructor(nombre, password){
    this.nombre = nombre;
    this.#password = password;
}

//metodo que compara contraseña actual con la ingresada
validarPassword(pass){
    return this.#password === pass;
}

//metodo para actualizar la contraseña solo si 
//la contraseña ingresada es igual a la ya existente
cambiarPassword(passActual, nuevoPass){
    if(this.validarPassword(passActual)){
        this.#password = nuevoPass;
        console.log("contraseña actualizada.");
    }else{
        console.error("Contraseña actual incorrecta.");
    }
}
}

const user = new Usuario("Ana", 1234);
console.log(user.validarPassword("1234"));//devuelve true (cumple la condicion)
console.log(user.validarPassword("1235"));//devuelve false(no cumpole la condicion)
user.cambiarPassword("1234", "abcd"); //Contraseña actualiza

//HERENCIA : la creacion de una clase que permita la creacion 
//de subclases -> consumir propiedades ya existentes en base a una clase padre

class Vehiculo {
    constructor(marca){
        this.marca = marca
    }

    encender(){
        console.log(`${this.marca} encendido.`)
    }
}

class Auto extends Vehiculo { //extends -> auto HEREDA de vehiculo
    constructor (marca, modelo){
        super(marca); //Utilizado para acceder al constructor de la clase padre
        this.modelo = modelo;
    }

    tocarBocina(){
        console.log("¡Beep beep!")
    }
}
const miAuto = new Auto("Toyota", "Corolla")
miAuto.encender(); //Toyota encendio.
miAuto.tocarBocina(); //¡Beep beep!


// Polimorfismo : transformar la clase original segun las necesidades
//de las sub clases
class Animal{
    emitirSonido(){
        console.log("El animal hace un sonido")
    }
}

class Perro extends Animal {
    emitirSonido(){
        console.log("El perro dice: ¡Guau!");
    }
}

class Gato extends Animal{
    emitirSonido(){
        console.log("El gato dice: ¡Miau!");
    }
}

const animales = [new Animal(), new Perro(), new Gato()];
animales.forEach((animal) => animal.emitirSonido());



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////